# Project objective and previous work audit

## Research objective

Recognize human activities from multiple body-worn IMUs despite missing sensors,
orientation changes, physical placement changes, and user variation. These are
different failure modes and need separate experiments. The resources describe
three connected objectives:

1. **O1: adaptive sensor relationships.** Test a physical/global/input-dependent
   graph against matched controls on actual REALDISP placement recordings.
2. **O2: orientation robustness.** After O1, compare raw axes, magnitude-only,
   and within-IMU norm/dot-product features, crossed with fixed/adaptive routing.
   Test numerical invariance under independent fixed IMU rotations; use
   training rotation augmentation as a control. Revisit normalization so it
   preserves the claimed invariance. Evaluate rotations separately from real
   displacement. Keep the temporal backbone and splits fixed.
3. **O3: federated learning.** After locking O1/O2 choices, simulate subjects as
   clients. Compare centralized/local-only/FedAvg/client-local normalization;
   isolate unseen-subject evaluation from known-client personalization. Report
   client variation, communication bytes and training cost. This is not an
   on-watch deployment or a privacy guarantee.

The most recent implementation handoff explicitly restricts current execution
to O1. The new workstation suite addresses that stage, not all three objectives.

## How the resources fit together

| Resource | Role and interpretation |
|---|---|
| `resources/additional_chat.txt` | Latest code/results handoff, 16 October; controlling scope and prior run inventory. |
| `resources/chat.tex` | Consolidated research decisions; distinguishes missing/oriented/displaced sensors and corrects broad novelty claims. |
| `resources/objectives_methodology.tex` | Detailed O1/O2/O3 hypotheses, mechanisms and evaluation rules. |
| `resources/roadmap_review.tex` | Corrects unsupported guarantees and proposes staged, leakage-controlled evidence. |
| `resources/mtp_1_a_report.tex` | Three-objective report; separates completed summer work from proposed extensions. |
| `resources/mtp1_a_full_report.tex` | Extended thesis draft; some earlier self-loop/regularizer choices differ from the latest agreed implementation. |
| `resources/mtp1_presentation.tex` | Concise objective and architecture presentation. |
| `resources/research_1.txt`, `research_2.txt` | Literature leads with malformed/missing equations and unverified broad claims, not experimental evidence. |
| `resources/colloquium_report.pdf` | Historical results and limitations, read with local Poppler text extraction. |
| `context.text`, `README.md`, `plan.md` | Older implementation narrative; do not override the later handoff. |
| `steps.md` | Agreed O1 implementation/evaluation checklist. |

## Completed prior work versus verified current implementation

The colloquium report describes a graph-BiGRU baseline, faster temporal
replacement, and graph-autoencoder training with simulated sensor dropout.
Its Table 5.1 reports 442.11 ms versus 13.39 ms for batch 128 and 125 steps,
with 94,751 versus 1,042,975 parameters. These are historical GPU batch timings,
not batch-one on-watch timings. Table 5.2 reports 89.22%, 54.74%, and 98.02%
macro-F1 on DSADS, OPPORTUNITY and REALDISP under its historical protocol.
Table 5.5 is a different dropout experiment. These are reported numbers, not
newly reproduced or directly comparable to the corrected workstation study.
The conclusion's 40.6x claim also differs from the roughly 33x table ratio.

Code inspection confirms that `PurePyTorchMambaBlock` has causal depthwise
convolution, projections, gating and residuals, but no selective state scan.
The scientific interpretation must refer to this implemented temporal backbone.
The O1 graph currently computes affinity at each timestep within a window;
reported routing heatmaps average those timestep matrices.

The previous O1 run comprises six conditions x three subjects x three seeds,
50 epochs each. Preprocessing used only subjects 2,5,15, so each split trained
on one subject. The saved results and latest handoff report mean induced F1
16.03% for no-graph and 12.74% for residual. The current evidence therefore does
not establish the residual graph's benefit. Old files are preserved.

## Changes validated for the workstation suite

- New full cache: 46 recordings, 81,666 windows, 17 ideal subjects and induced
  recordings for subjects 2,5,15. Historical processed tensors are untouched.
- Verified sensor ordering against the supplied REALDISP manual: Back, LUA,
  RUA, LLA, RLA, LT, RT, LC, RC. Each has acc XYZ and gyro XYZ.
- Recording suffix 4–7 denotes the number of displaced sensors, as documented
  in the manual; retained in source identity, with the scenario called induced.
- Train-only per-sensor/channel normalization, subject-separated validation,
  full split indices and raw recording provenance.
- DynamicWHAR layout fixed from B,T,N,F to B,N,T,F. A subclass fixes upstream
  batch-one squeeze behavior while retaining its algebra and vendored source.
- Separate matched dropout/GAE/mask controls; validation-only model selection.
- CUDA BF16, fused AdamW, GPU-resident fold tensors, finite-loss/gradient checks,
  epoch checkpoints, RNG restoration, source/config locks and GPU telemetry.
- Eleven tests pass, including synthetic interruption/resume and held-out
  normalization independence. Ten real-data smoke conditions passed.

Class coverage is uneven: subject 7 has only 238 labeled ideal windows.
`data_audit.json` records counts rather than assuming every subject covers all
33 classes. Primary macro-F1 explicitly uses 33 classes; common-class paired
degradation is reported separately. Old results used an implicit label set.
Do not equate a change in the metric definition with a model improvement.

See `TRAINING_PLAN.md` for the fixed experiment matrix and `TRAINING_RUN.md`
for execution, outputs, resumption and environment provenance.
