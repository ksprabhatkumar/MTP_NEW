# Objective 1: Placement-Aware Residual Dynamic Routing

## Summary

Build and evaluate a corrected residual inter-sensor graph for REALDISP only. The study will use nested LOSO, ideal-placement recognition as the primary task, and recorded induced-displacement tests for subjects 2, 5, and 15. DynamicWHAR will be ported from its official implementation as a separately documented matched comparator.

## Key changes

- Audit the supplied REALDISP raw files once placed in `har_data/REALDISP/`; create a manifest containing subject, scenario (`ideal`, `self`, `induced`), recording ID, window bounds, activity label, and sensor availability.
- Replace preprocessing that globally normalizes and discards scenario identity. Use 50-sample windows with stride 25, nine sensor nodes, and acceleration/gyroscope channels only (`[T, 9, 6]`). Fit normalization solely on each fold’s training subjects and apply it unchanged to validation and test data.
- Replace the current unconstrained adjacency with the O1 routing contract:
  - nonnegative physical prior, globally learned branch, and per-window query/key affinity;
  - softmax-normalized nonnegative mixture weights, initialized to favor the physical prior;
  - no graph self-edges, explicit sender-availability masking, finite empty-row handling, and row normalization;
  - separate residual self-feature path during message passing.
- Update the model interface to accept an optional sensor-availability mask and return routing diagnostics: final adjacency, per-branch contributions, mixture weights, and masked-row counts.
- Refactor training around explicit fold manifests: outer held-out test subject, a distinct rotating validation subject, and all other ideal recordings for training. Checkpoints and hyperparameters are selected only from validation macro-F1.
- Use classification loss as the primary O1 objective. Retain the inherited GAE reconstruction path only as a controlled on/off ablation, with reconstruction applied only to known masked training targets.
- Implement matched controls with identical encoder, temporal backbone, optimization budget, input channels, and folds: no cross-sensor graph, normalized physical graph, global-only graph, dynamic-only graph, full residual graph, fixed graph plus augmentation, availability-mask ablation, and GAE on/off.
- Port and adapt the official DynamicWHAR implementation to the same processed inputs and splits; label any unavoidable architecture or preprocessing differences and report it separately from internally matched ablations.
- Evaluate ideal placement for every outer subject and induced-placement generalization for test subjects 2, 5, and 15, using only matched subject/class/scenario pairs. Keep self-placement available as an audited supplementary condition, not a substitute for induced-placement evidence.

## Test plan and evidence

- Add unit tests for adjacency shape, nonnegativity, zero diagonal, row normalization, sender masking, all-senders-missing behavior, finite outputs/gradients, and diagnostic reproducibility in evaluation mode.
- Add data tests for channel ordering, scenario parsing, no overlap between train/validation/test recordings, training-only normalization, class coverage, and induced-placement coverage.
- Run each internal condition with three fixed seeds. Report subject-level macro-F1 as primary, accuracy and weighted F1 as supporting metrics, ideal-to-induced degradation, per-class errors, seed variation, and worst-subject performance.
- Measure parameter count, batch-one median/p95 latency, and peak memory with feature extraction and dynamic graph construction included.
- Preserve versioned configs, fold manifests, checkpoints, raw per-seed predictions, routing summaries, and plots so the result is reproducible even if the hypothesis is negative.

## Assumptions

- You will provide the official raw REALDISP recordings under `har_data/REALDISP/`.
- The initial physical sensor topology remains the repository’s nine-node anatomical prior, but it will be documented and tested only as a prior rather than treated as ground truth.
- Objective 2 rotation-invariant features and Objective 3 federated learning remain out of scope; rotation/dropout augmentation is used only as an O1 robustness control.
- A successful Objective 1 result is evidence that residual routing improves recorded-placement robustness beyond matched controls without unacceptable ideal-placement or latency degradation; it is not a claim that dynamic wearable graphs are novel.
