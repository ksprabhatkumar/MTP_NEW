# Workstation training

Run from the project root. The active implementation scope is Objective 1; see
[the audit and plan](TRAINING_PLAN.md).

```powershell
.\prabhat\Scripts\python.exe -u run_training.py --mode full --hours 5.5
```

This single command checks the full data cache, runs tests and ten smoke
conditions, measures full-epoch GPU throughput, freezes one common epoch count,
and executes all 118 jobs sequentially. It never silently falls back to CPU.
The 5.5-hour estimate applies to the training suite; setup/smoke/calibration add
overhead. Hardware load and checkpoint IO can change the actual finish time.
All scheduled jobs finish; there is no mid-experiment time cutoff.

For just the demo:

```powershell
.\prabhat\Scripts\python.exe -u run_training.py --mode smoke
```

To resume an interrupted run, use its existing output directory and original
batch size. Completed jobs are skipped and incomplete jobs resume from the last
saved epoch, including optimizer and random-generator states:

```powershell
.\prabhat\Scripts\python.exe -u run_training.py --mode full --output results/RUN_DIRECTORY --batch-size 256
```

The source and data must match the recorded snapshot. A concurrent writer to the
same directory is rejected. Check `status.json`, `run.log`, `schedule.json` and
`gpu_telemetry.csv` for progress, frozen settings, GPU activity and failures.
Per-job `epochs.jsonl`, `best.pt`, `latest.pt`, predictions, confusion matrices,
routing diagrams and `result.json` live under `jobs/CONDITION/subject_XX/seed_YY/`.
Fold manifests and normalization live under `folds/`. `fold_metrics.csv` and
`summary.json` update after each completed job. Smoke results are separate.

The primary study is ten conditions x three subjects x three seeds (90 jobs).
Another 28 jobs complete no-graph/residual ideal LOSO on the remaining 14
subjects using seed 13. Ideal/induced/self macro-F1 uses all 33 declared classes;
the paired degradation additionally uses common supported classes. This differs
from the historical implicit-class metric and must be labeled in comparisons.

Plots use the workstation's existing Anaconda matplotlib installation and read
only saved JSON. Set `--plot-python PATH` to choose another plotting interpreter.
Training and testing always use `prabhat`. Re-export plots independently with:

```powershell
python plot_training_results.py results/RUN_DIRECTORY
```

## Environment provenance

`prabhat` was created with the local Python 3.11.15 interpreter. Network package
download failed due to the configured connection, so compatible installed local
distributions were copied from `pr/Lib/site-packages` into the new environment.
`python -m pip check` passed; CUDA matrix multiplication was verified on the
NVIDIA RTX 2000 Ada Generation (16 GB). Each run saves `requirements.lock.txt`.
The old environment remains unused because automatic approval review blocked
its removal and sandbox approval is disabled.

For a future network-enabled clean install, the official PyTorch 2.5.1 command
uses the [CUDA 12.1 wheel index](https://docs.pytorch.org/get-started/previous-versions/):

```powershell
uv venv prabhat --python .python/cpython-3.11.15-windows-x86_64-none/python.exe
uv pip install --python prabhat/Scripts/python.exe torch==2.5.1 --index-url https://download.pytorch.org/whl/cu121
uv pip install --python prabhat/Scripts/python.exe -r requirements.txt
```

`mamba-ssm`, `causal-conv1d`, and PyG are absent because the current O1 model does
not import them. Its temporal block is a gated convolution, not official Mamba.
DynamicWHAR preserves the vendored upstream code/license; its adapter transposes
input dimensions and fixes the upstream batch-one squeeze via a subclass.
